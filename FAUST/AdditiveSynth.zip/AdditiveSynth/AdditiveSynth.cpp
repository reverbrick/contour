/* ------------------------------------------------------------
name: "AdditiveSynth"
Code generated with Faust 2.20.0 (https://faust.grame.fr)
Compilation options: -lang cpp -scal -ftz 0
------------------------------------------------------------ */

#ifndef  __mydsp_H__
#define  __mydsp_H__

/************************************************************************
 IMPORTANT NOTE : this file contains two clearly delimited sections :
 the ARCHITECTURE section (in two parts) and the USER section. Each section
 is governed by its own copyright and license. Please check individually
 each section for license and copyright information.
 *************************************************************************/

/*******************BEGIN ARCHITECTURE SECTION (part 1/2)****************/

/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2019 GRAME, Centre National de Creation Musicale &
 Aalborg University (Copenhagen, Denmark)
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 
 ************************************************************************
 ************************************************************************/

#include "AdditiveSynth.h"

/************************** BEGIN meta.h **************************/
/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2017 GRAME, Centre National de Creation Musicale
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 ************************************************************************/

#ifndef __meta__
#define __meta__

struct Meta
{
    virtual ~Meta() {};
    virtual void declare(const char* key, const char* value) = 0;
    
};

#endif
/**************************  END  meta.h **************************/
/************************** BEGIN dsp.h **************************/
/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2017 GRAME, Centre National de Creation Musicale
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 ************************************************************************/

#ifndef __dsp__
#define __dsp__

#include <string>
#include <vector>

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif

class UI;
struct Meta;

/**
 * DSP memory manager.
 */

struct dsp_memory_manager {
    
    virtual ~dsp_memory_manager() {}
    
    virtual void* allocate(size_t size) = 0;
    virtual void destroy(void* ptr) = 0;
    
};

/**
* Signal processor definition.
*/

class dsp {

    public:

        dsp() {}
        virtual ~dsp() {}

        /* Return instance number of audio inputs */
        virtual int getNumInputs() = 0;
    
        /* Return instance number of audio outputs */
        virtual int getNumOutputs() = 0;
    
        /**
         * Trigger the ui_interface parameter with instance specific calls
         * to 'addBtton', 'addVerticalSlider'... in order to build the UI.
         *
         * @param ui_interface - the user interface builder
         */
        virtual void buildUserInterface(UI* ui_interface) = 0;
    
        /* Returns the sample rate currently used by the instance */
        virtual int getSampleRate() = 0;
    
        /**
         * Global init, calls the following methods:
         * - static class 'classInit': static tables initialization
         * - 'instanceInit': constants and instance state initialization
         *
         * @param sample_rate - the sampling rate in Hertz
         */
        virtual void init(int sample_rate) = 0;

        /**
         * Init instance state
         *
         * @param sample_rate - the sampling rate in Hertz
         */
        virtual void instanceInit(int sample_rate) = 0;

        /**
         * Init instance constant state
         *
         * @param sample_rate - the sampling rate in Hertz
         */
        virtual void instanceConstants(int sample_rate) = 0;
    
        /* Init default control parameters values */
        virtual void instanceResetUserInterface() = 0;
    
        /* Init instance state (delay lines...) */
        virtual void instanceClear() = 0;
 
        /**
         * Return a clone of the instance.
         *
         * @return a copy of the instance on success, otherwise a null pointer.
         */
        virtual dsp* clone() = 0;
    
        /**
         * Trigger the Meta* parameter with instance specific calls to 'declare' (key, value) metadata.
         *
         * @param m - the Meta* meta user
         */
        virtual void metadata(Meta* m) = 0;
    
        /**
         * DSP instance computation, to be called with successive in/out audio buffers.
         *
         * @param count - the number of frames to compute
         * @param inputs - the input audio buffers as an array of non-interleaved FAUSTFLOAT samples (eiher float, double or quad)
         * @param outputs - the output audio buffers as an array of non-interleaved FAUSTFLOAT samples (eiher float, double or quad)
         *
         */
        virtual void compute(int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) = 0;
    
        /**
         * DSP instance computation: alternative method to be used by subclasses.
         *
         * @param date_usec - the timestamp in microsec given by audio driver.
         * @param count - the number of frames to compute
         * @param inputs - the input audio buffers as an array of non-interleaved FAUSTFLOAT samples (either float, double or quad)
         * @param outputs - the output audio buffers as an array of non-interleaved FAUSTFLOAT samples (either float, double or quad)
         *
         */
        virtual void compute(double /*date_usec*/, int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) { compute(count, inputs, outputs); }
       
};

/**
 * Generic DSP decorator.
 */

class decorator_dsp : public dsp {

    protected:

        dsp* fDSP;

    public:

        decorator_dsp(dsp* dsp = nullptr):fDSP(dsp) {}
        virtual ~decorator_dsp() { delete fDSP; }

        virtual int getNumInputs() { return fDSP->getNumInputs(); }
        virtual int getNumOutputs() { return fDSP->getNumOutputs(); }
        virtual void buildUserInterface(UI* ui_interface) { fDSP->buildUserInterface(ui_interface); }
        virtual int getSampleRate() { return fDSP->getSampleRate(); }
        virtual void init(int sample_rate) { fDSP->init(sample_rate); }
        virtual void instanceInit(int sample_rate) { fDSP->instanceInit(sample_rate); }
        virtual void instanceConstants(int sample_rate) { fDSP->instanceConstants(sample_rate); }
        virtual void instanceResetUserInterface() { fDSP->instanceResetUserInterface(); }
        virtual void instanceClear() { fDSP->instanceClear(); }
        virtual decorator_dsp* clone() { return new decorator_dsp(fDSP->clone()); }
        virtual void metadata(Meta* m) { fDSP->metadata(m); }
        // Beware: subclasses usually have to overload the two 'compute' methods
        virtual void compute(int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) { fDSP->compute(count, inputs, outputs); }
        virtual void compute(double date_usec, int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) { fDSP->compute(date_usec, count, inputs, outputs); }
    
};

/**
 * DSP factory class.
 */

class dsp_factory {
    
    protected:
    
        // So that to force sub-classes to use deleteDSPFactory(dsp_factory* factory);
        virtual ~dsp_factory() {}
    
    public:
    
        virtual std::string getName() = 0;
        virtual std::string getSHAKey() = 0;
        virtual std::string getDSPCode() = 0;
        virtual std::string getCompileOptions() = 0;
        virtual std::vector<std::string> getLibraryList() = 0;
        virtual std::vector<std::string> getIncludePathnames() = 0;
    
        virtual dsp* createDSPInstance() = 0;
    
        virtual void setMemoryManager(dsp_memory_manager* manager) = 0;
        virtual dsp_memory_manager* getMemoryManager() = 0;
    
};

/**
 * On Intel set FZ (Flush to Zero) and DAZ (Denormals Are Zero)
 * flags to avoid costly denormals.
 */

#ifdef __SSE__
    #include <xmmintrin.h>
    #ifdef __SSE2__
        #define AVOIDDENORMALS _mm_setcsr(_mm_getcsr() | 0x8040)
    #else
        #define AVOIDDENORMALS _mm_setcsr(_mm_getcsr() | 0x8000)
    #endif
#else
    #define AVOIDDENORMALS
#endif

#endif
/**************************  END  dsp.h **************************/
/************************** BEGIN MapUI.h **************************/
/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2017 GRAME, Centre National de Creation Musicale
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 ************************************************************************/

#ifndef FAUST_MAPUI_H
#define FAUST_MAPUI_H

#include <vector>
#include <map>
#include <string>

/************************** BEGIN UI.h **************************/
/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2017 GRAME, Centre National de Creation Musicale
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 ************************************************************************/

#ifndef __UI_H__
#define __UI_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif

/*******************************************************************************
 * UI : Faust DSP User Interface
 * User Interface as expected by the buildUserInterface() method of a DSP.
 * This abstract class contains only the method that the Faust compiler can
 * generate to describe a DSP user interface.
 ******************************************************************************/

struct Soundfile;

template <typename REAL>
class UIReal
{
    
    public:
        
        UIReal() {}
        virtual ~UIReal() {}
        
        // -- widget's layouts
        
        virtual void openTabBox(const char* label) = 0;
        virtual void openHorizontalBox(const char* label) = 0;
        virtual void openVerticalBox(const char* label) = 0;
        virtual void closeBox() = 0;
        
        // -- active widgets
        
        virtual void addButton(const char* label, REAL* zone) = 0;
        virtual void addCheckButton(const char* label, REAL* zone) = 0;
        virtual void addVerticalSlider(const char* label, REAL* zone, REAL init, REAL min, REAL max, REAL step) = 0;
        virtual void addHorizontalSlider(const char* label, REAL* zone, REAL init, REAL min, REAL max, REAL step) = 0;
        virtual void addNumEntry(const char* label, REAL* zone, REAL init, REAL min, REAL max, REAL step) = 0;
        
        // -- passive widgets
        
        virtual void addHorizontalBargraph(const char* label, REAL* zone, REAL min, REAL max) = 0;
        virtual void addVerticalBargraph(const char* label, REAL* zone, REAL min, REAL max) = 0;
        
        // -- soundfiles
        
        virtual void addSoundfile(const char* label, const char* filename, Soundfile** sf_zone) = 0;
        
        // -- metadata declarations
        
        virtual void declare(REAL* zone, const char* key, const char* val) {}
};

class UI : public UIReal<FAUSTFLOAT>
{

    public:

        UI() {}
        virtual ~UI() {}
};

#endif
/**************************  END  UI.h **************************/
/************************** BEGIN PathBuilder.h **************************/
/************************************************************************
 FAUST Architecture File
 Copyright (C) 2003-2017 GRAME, Centre National de Creation Musicale
 ---------------------------------------------------------------------
 This Architecture section is free software; you can redistribute it
 and/or modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3 of
 the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; If not, see <http://www.gnu.org/licenses/>.
 
 EXCEPTION : As a special exception, you may create a larger work
 that contains this FAUST architecture section and distribute
 that work under terms of your choice, so long as this FAUST
 architecture section is not modified.
 ************************************************************************/

#ifndef FAUST_PATHBUILDER_H
#define FAUST_PATHBUILDER_H

#include <vector>
#include <string>
#include <algorithm>

/*******************************************************************************
 * PathBuilder : Faust User Interface
 * Helper class to build complete hierarchical path for UI items.
 ******************************************************************************/

class PathBuilder
{

    protected:
    
        std::vector<std::string> fControlsLevel;
       
    public:
    
        PathBuilder() {}
        virtual ~PathBuilder() {}
    
        std::string buildPath(const std::string& label) 
        {
            std::string res = "/";
            for (size_t i = 0; i < fControlsLevel.size(); i++) {
                res += fControlsLevel[i];
                res += "/";
            }
            res += label;
            std::replace(res.begin(), res.end(), ' ', '_');
            return res;
        }
    
        void pushLabel(const std::string& label) { fControlsLevel.push_back(label); }
        void popLabel() { fControlsLevel.pop_back(); }
    
};

#endif  // FAUST_PATHBUILDER_H
/**************************  END  PathBuilder.h **************************/

/*******************************************************************************
 * MapUI : Faust User Interface
 * This class creates a map of complete hierarchical path and zones for each UI items.
 ******************************************************************************/

class MapUI : public UI, public PathBuilder
{
    
    protected:
    
        // Complete path map
        std::map<std::string, FAUSTFLOAT*> fPathZoneMap;
    
        // Label zone map
        std::map<std::string, FAUSTFLOAT*> fLabelZoneMap;
    
    public:
        
        MapUI() {};
        virtual ~MapUI() {};
        
        // -- widget's layouts
        void openTabBox(const char* label)
        {
            pushLabel(label);
        }
        void openHorizontalBox(const char* label)
        {
            pushLabel(label);
        }
        void openVerticalBox(const char* label)
        {
            pushLabel(label);
        }
        void closeBox()
        {
            popLabel();
        }
        
        // -- active widgets
        void addButton(const char* label, FAUSTFLOAT* zone)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        void addCheckButton(const char* label, FAUSTFLOAT* zone)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        void addVerticalSlider(const char* label, FAUSTFLOAT* zone, FAUSTFLOAT init, FAUSTFLOAT fmin, FAUSTFLOAT fmax, FAUSTFLOAT step)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        void addHorizontalSlider(const char* label, FAUSTFLOAT* zone, FAUSTFLOAT init, FAUSTFLOAT fmin, FAUSTFLOAT fmax, FAUSTFLOAT step)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        void addNumEntry(const char* label, FAUSTFLOAT* zone, FAUSTFLOAT init, FAUSTFLOAT fmin, FAUSTFLOAT fmax, FAUSTFLOAT step)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        
        // -- passive widgets
        void addHorizontalBargraph(const char* label, FAUSTFLOAT* zone, FAUSTFLOAT fmin, FAUSTFLOAT fmax)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
        void addVerticalBargraph(const char* label, FAUSTFLOAT* zone, FAUSTFLOAT fmin, FAUSTFLOAT fmax)
        {
            fPathZoneMap[buildPath(label)] = zone;
            fLabelZoneMap[label] = zone;
        }
    
        // -- soundfiles
        virtual void addSoundfile(const char* label, const char* filename, Soundfile** sf_zone) {}
        
        // -- metadata declarations
        void declare(FAUSTFLOAT* zone, const char* key, const char* val)
        {}
        
        // set/get
        void setParamValue(const std::string& path, FAUSTFLOAT value)
        {
            if (fPathZoneMap.find(path) != fPathZoneMap.end()) {
                *fPathZoneMap[path] = value;
            } else if (fLabelZoneMap.find(path) != fLabelZoneMap.end()) {
                *fLabelZoneMap[path] = value;
            }
        }
        
        FAUSTFLOAT getParamValue(const std::string& path)
        {
            if (fPathZoneMap.find(path) != fPathZoneMap.end()) {
                return *fPathZoneMap[path];
            } else if (fLabelZoneMap.find(path) != fLabelZoneMap.end()) {
                return *fLabelZoneMap[path];
            } else {
                return FAUSTFLOAT(0);
            }
        }
    
        // map access 
        std::map<std::string, FAUSTFLOAT*>& getMap() { return fPathZoneMap; }
        
        int getParamsCount() { return int(fPathZoneMap.size()); }
        
        std::string getParamAddress(int index)
        { 
            std::map<std::string, FAUSTFLOAT*>::iterator it = fPathZoneMap.begin();
            while (index-- > 0 && it++ != fPathZoneMap.end()) {}
            return (*it).first;
        }
    
        std::string getParamAddress(FAUSTFLOAT* zone)
        {
            std::map<std::string, FAUSTFLOAT*>::iterator it = fPathZoneMap.begin();
            do {
                if ((*it).second == zone) return (*it).first;
            }
            while (it++ != fPathZoneMap.end());
            return "";
        }
    
        static bool endsWith(std::string const& str, std::string const& end)
        {
            size_t l1 = str.length();
            size_t l2 = end.length();
            return (l1 >= l2) && (0 == str.compare(l1 - l2, l2, end));
        }
};


#endif // FAUST_MAPUI_H
/**************************  END  MapUI.h **************************/

/******************************************************************************
 *******************************************************************************
 
 VECTOR INTRINSICS
 
 *******************************************************************************
 *******************************************************************************/


/********************END ARCHITECTURE SECTION (part 1/2)****************/

/**************************BEGIN USER SECTION **************************/

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif 

#include <algorithm>
#include <cmath>
#include <math.h>


#ifndef FAUSTCLASS 
#define FAUSTCLASS mydsp
#endif

#ifdef __APPLE__ 
#define exp10f __exp10f
#define exp10 __exp10
#endif

class mydsp : public dsp {
	
 private:
	
	int fSampleRate;
	float fConst0;
	float fConst1;
	FAUSTFLOAT fEntry0;
	FAUSTFLOAT fHslider0;
	int iVec0[2];
	float fRec0[2];
	float fRec1[2];
	FAUSTFLOAT fHslider1;
	float fConst2;
	FAUSTFLOAT fHslider2;
	FAUSTFLOAT fButton0;
	float fVec1[2];
	float fRec2[2];
	FAUSTFLOAT fHslider3;
	FAUSTFLOAT fHslider4;
	FAUSTFLOAT fHslider5;
	int iRec3[2];
	float fConst3;
	float fRec4[2];
	float fRec5[2];
	FAUSTFLOAT fHslider6;
	FAUSTFLOAT fHslider7;
	FAUSTFLOAT fHslider8;
	FAUSTFLOAT fHslider9;
	FAUSTFLOAT fHslider10;
	float fConst4;
	float fRec6[2];
	float fRec7[2];
	FAUSTFLOAT fHslider11;
	FAUSTFLOAT fHslider12;
	FAUSTFLOAT fHslider13;
	FAUSTFLOAT fHslider14;
	FAUSTFLOAT fHslider15;
	float fConst5;
	float fRec8[2];
	float fRec9[2];
	FAUSTFLOAT fHslider16;
	FAUSTFLOAT fHslider17;
	FAUSTFLOAT fHslider18;
	FAUSTFLOAT fHslider19;
	FAUSTFLOAT fHslider20;
	float fConst6;
	float fRec10[2];
	float fRec11[2];
	FAUSTFLOAT fHslider21;
	FAUSTFLOAT fHslider22;
	FAUSTFLOAT fHslider23;
	FAUSTFLOAT fHslider24;
	FAUSTFLOAT fHslider25;
	float fConst7;
	float fRec12[2];
	float fRec13[2];
	FAUSTFLOAT fHslider26;
	FAUSTFLOAT fHslider27;
	FAUSTFLOAT fHslider28;
	FAUSTFLOAT fHslider29;
	FAUSTFLOAT fHslider30;
	float fConst8;
	float fRec14[2];
	float fRec15[2];
	FAUSTFLOAT fHslider31;
	FAUSTFLOAT fHslider32;
	FAUSTFLOAT fHslider33;
	FAUSTFLOAT fHslider34;
	FAUSTFLOAT fHslider35;
	float fConst9;
	float fRec16[2];
	float fRec17[2];
	FAUSTFLOAT fHslider36;
	FAUSTFLOAT fHslider37;
	FAUSTFLOAT fHslider38;
	FAUSTFLOAT fHslider39;
	FAUSTFLOAT fHslider40;
	
 public:
	
	void metadata(Meta* m) { 
		m->declare("basics.lib/name", "Faust Basic Element Library");
		m->declare("basics.lib/version", "0.1");
		m->declare("envelopes.lib/adsr:author", "Yann Orlarey");
		m->declare("envelopes.lib/author", "GRAME");
		m->declare("envelopes.lib/copyright", "GRAME");
		m->declare("envelopes.lib/license", "LGPL with exception");
		m->declare("envelopes.lib/name", "Faust Envelope Library");
		m->declare("envelopes.lib/version", "0.0");
		m->declare("filename", "AdditiveSynth.dsp");
		m->declare("filters.lib/lowpass0_highpass1", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("filters.lib/name", "Faust Filters Library");
		m->declare("filters.lib/nlf2:author", "Julius O. Smith III");
		m->declare("filters.lib/nlf2:copyright", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("filters.lib/nlf2:license", "MIT-style STK-4.3 license");
		m->declare("maths.lib/author", "GRAME");
		m->declare("maths.lib/copyright", "GRAME");
		m->declare("maths.lib/license", "LGPL with exception");
		m->declare("maths.lib/name", "Faust Math Library");
		m->declare("maths.lib/version", "2.1");
		m->declare("name", "AdditiveSynth");
		m->declare("oscillators.lib/name", "Faust Oscillator Library");
		m->declare("oscillators.lib/version", "0.0");
	}

	virtual int getNumInputs() {
		return 0;
	}
	virtual int getNumOutputs() {
		return 1;
	}
	virtual int getInputRate(int channel) {
		int rate;
		switch ((channel)) {
			default: {
				rate = -1;
				break;
			}
		}
		return rate;
	}
	virtual int getOutputRate(int channel) {
		int rate;
		switch ((channel)) {
			case 0: {
				rate = 1;
				break;
			}
			default: {
				rate = -1;
				break;
			}
		}
		return rate;
	}
	
	static void classInit(int sample_rate) {
	}
	
	virtual void instanceConstants(int sample_rate) {
		fSampleRate = sample_rate;
		fConst0 = std::min<float>(192000.0f, std::max<float>(1.0f, float(fSampleRate)));
		fConst1 = (6.28318548f / fConst0);
		fConst2 = (0.00999999978f * fConst0);
		fConst3 = (12.566371f / fConst0);
		fConst4 = (18.849556f / fConst0);
		fConst5 = (25.1327419f / fConst0);
		fConst6 = (31.415926f / fConst0);
		fConst7 = (37.6991119f / fConst0);
		fConst8 = (43.982296f / fConst0);
		fConst9 = (50.2654839f / fConst0);
	}
	
	virtual void instanceResetUserInterface() {
		fEntry0 = FAUSTFLOAT(440.0f);
		fHslider0 = FAUSTFLOAT(0.0f);
		fHslider1 = FAUSTFLOAT(1.0f);
		fHslider2 = FAUSTFLOAT(1.0f);
		fButton0 = FAUSTFLOAT(0.0f);
		fHslider3 = FAUSTFLOAT(1.0f);
		fHslider4 = FAUSTFLOAT(1.0f);
		fHslider5 = FAUSTFLOAT(1.0f);
		fHslider6 = FAUSTFLOAT(1.0f);
		fHslider7 = FAUSTFLOAT(1.0f);
		fHslider8 = FAUSTFLOAT(1.0f);
		fHslider9 = FAUSTFLOAT(1.0f);
		fHslider10 = FAUSTFLOAT(1.0f);
		fHslider11 = FAUSTFLOAT(1.0f);
		fHslider12 = FAUSTFLOAT(1.0f);
		fHslider13 = FAUSTFLOAT(1.0f);
		fHslider14 = FAUSTFLOAT(1.0f);
		fHslider15 = FAUSTFLOAT(1.0f);
		fHslider16 = FAUSTFLOAT(1.0f);
		fHslider17 = FAUSTFLOAT(1.0f);
		fHslider18 = FAUSTFLOAT(1.0f);
		fHslider19 = FAUSTFLOAT(1.0f);
		fHslider20 = FAUSTFLOAT(1.0f);
		fHslider21 = FAUSTFLOAT(1.0f);
		fHslider22 = FAUSTFLOAT(1.0f);
		fHslider23 = FAUSTFLOAT(1.0f);
		fHslider24 = FAUSTFLOAT(1.0f);
		fHslider25 = FAUSTFLOAT(1.0f);
		fHslider26 = FAUSTFLOAT(1.0f);
		fHslider27 = FAUSTFLOAT(1.0f);
		fHslider28 = FAUSTFLOAT(1.0f);
		fHslider29 = FAUSTFLOAT(1.0f);
		fHslider30 = FAUSTFLOAT(1.0f);
		fHslider31 = FAUSTFLOAT(1.0f);
		fHslider32 = FAUSTFLOAT(1.0f);
		fHslider33 = FAUSTFLOAT(1.0f);
		fHslider34 = FAUSTFLOAT(1.0f);
		fHslider35 = FAUSTFLOAT(1.0f);
		fHslider36 = FAUSTFLOAT(1.0f);
		fHslider37 = FAUSTFLOAT(1.0f);
		fHslider38 = FAUSTFLOAT(1.0f);
		fHslider39 = FAUSTFLOAT(1.0f);
		fHslider40 = FAUSTFLOAT(1.0f);
	}
	
	virtual void instanceClear() {
		for (int l0 = 0; (l0 < 2); l0 = (l0 + 1)) {
			iVec0[l0] = 0;
		}
		for (int l1 = 0; (l1 < 2); l1 = (l1 + 1)) {
			fRec0[l1] = 0.0f;
		}
		for (int l2 = 0; (l2 < 2); l2 = (l2 + 1)) {
			fRec1[l2] = 0.0f;
		}
		for (int l3 = 0; (l3 < 2); l3 = (l3 + 1)) {
			fVec1[l3] = 0.0f;
		}
		for (int l4 = 0; (l4 < 2); l4 = (l4 + 1)) {
			fRec2[l4] = 0.0f;
		}
		for (int l5 = 0; (l5 < 2); l5 = (l5 + 1)) {
			iRec3[l5] = 0;
		}
		for (int l6 = 0; (l6 < 2); l6 = (l6 + 1)) {
			fRec4[l6] = 0.0f;
		}
		for (int l7 = 0; (l7 < 2); l7 = (l7 + 1)) {
			fRec5[l7] = 0.0f;
		}
		for (int l8 = 0; (l8 < 2); l8 = (l8 + 1)) {
			fRec6[l8] = 0.0f;
		}
		for (int l9 = 0; (l9 < 2); l9 = (l9 + 1)) {
			fRec7[l9] = 0.0f;
		}
		for (int l10 = 0; (l10 < 2); l10 = (l10 + 1)) {
			fRec8[l10] = 0.0f;
		}
		for (int l11 = 0; (l11 < 2); l11 = (l11 + 1)) {
			fRec9[l11] = 0.0f;
		}
		for (int l12 = 0; (l12 < 2); l12 = (l12 + 1)) {
			fRec10[l12] = 0.0f;
		}
		for (int l13 = 0; (l13 < 2); l13 = (l13 + 1)) {
			fRec11[l13] = 0.0f;
		}
		for (int l14 = 0; (l14 < 2); l14 = (l14 + 1)) {
			fRec12[l14] = 0.0f;
		}
		for (int l15 = 0; (l15 < 2); l15 = (l15 + 1)) {
			fRec13[l15] = 0.0f;
		}
		for (int l16 = 0; (l16 < 2); l16 = (l16 + 1)) {
			fRec14[l16] = 0.0f;
		}
		for (int l17 = 0; (l17 < 2); l17 = (l17 + 1)) {
			fRec15[l17] = 0.0f;
		}
		for (int l18 = 0; (l18 < 2); l18 = (l18 + 1)) {
			fRec16[l18] = 0.0f;
		}
		for (int l19 = 0; (l19 < 2); l19 = (l19 + 1)) {
			fRec17[l19] = 0.0f;
		}
	}
	
	virtual void init(int sample_rate) {
		classInit(sample_rate);
		instanceInit(sample_rate);
	}
	virtual void instanceInit(int sample_rate) {
		instanceConstants(sample_rate);
		instanceResetUserInterface();
		instanceClear();
	}
	
	virtual mydsp* clone() {
		return new mydsp();
	}
	
	virtual int getSampleRate() {
		return fSampleRate;
	}
	
	virtual void buildUserInterface(UI* ui_interface) {
		ui_interface->openVerticalBox("AdditiveSynth");
		ui_interface->addHorizontalSlider("A0", &fHslider2, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A1", &fHslider7, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A2", &fHslider12, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A3", &fHslider17, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A4", &fHslider22, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A5", &fHslider27, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A6", &fHslider32, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("A7", &fHslider37, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D0", &fHslider4, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D1", &fHslider9, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D2", &fHslider14, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D3", &fHslider19, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D4", &fHslider24, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D5", &fHslider29, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D6", &fHslider34, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("D7", &fHslider39, 1.0f, 0.0f, 400.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R0", &fHslider5, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R1", &fHslider10, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R2", &fHslider15, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R3", &fHslider20, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R4", &fHslider25, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R5", &fHslider30, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R6", &fHslider35, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("R7", &fHslider40, 1.0f, 0.0f, 800.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S0", &fHslider3, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S1", &fHslider8, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S2", &fHslider13, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S3", &fHslider18, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S4", &fHslider23, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S5", &fHslider28, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S6", &fHslider33, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("S7", &fHslider38, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->declare(&fHslider0, "midi", "pitchwheel");
		ui_interface->addHorizontalSlider("bend", &fHslider0, 0.0f, -2.0f, 2.0f, 0.00999999978f);
		ui_interface->declare(&fEntry0, "unit", "Hz");
		ui_interface->addNumEntry("freq", &fEntry0, 440.0f, 20.0f, 20000.0f, 1.0f);
		ui_interface->addButton("gate", &fButton0);
		ui_interface->addHorizontalSlider("vol0", &fHslider1, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol1", &fHslider6, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol2", &fHslider11, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol3", &fHslider16, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol4", &fHslider21, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol5", &fHslider26, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol6", &fHslider31, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->addHorizontalSlider("vol7", &fHslider36, 1.0f, 0.0f, 1.0f, 0.00100000005f);
		ui_interface->closeBox();
	}
	
	virtual void compute(int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) {
		FAUSTFLOAT* output0 = outputs[0];
		float fSlow0 = (float(fEntry0) * std::pow(2.0f, (0.0833333358f * float(fHslider0))));
		float fSlow1 = (fConst1 * fSlow0);
		float fSlow2 = std::sin(fSlow1);
		float fSlow3 = std::cos(fSlow1);
		float fSlow4 = float(fHslider1);
		float fSlow5 = std::max<float>(1.0f, (fConst2 * float(fHslider2)));
		float fSlow6 = (1.0f / fSlow5);
		float fSlow7 = float(fButton0);
		float fSlow8 = float(fHslider3);
		float fSlow9 = ((1.0f - fSlow8) / std::max<float>(1.0f, (fConst2 * float(fHslider4))));
		float fSlow10 = (fSlow8 / std::max<float>(1.0f, (fConst2 * float(fHslider5))));
		int iSlow11 = (fSlow7 == 0.0f);
		float fSlow12 = (fConst3 * fSlow0);
		float fSlow13 = std::sin(fSlow12);
		float fSlow14 = std::cos(fSlow12);
		float fSlow15 = float(fHslider6);
		float fSlow16 = std::max<float>(1.0f, (fConst2 * float(fHslider7)));
		float fSlow17 = (1.0f / fSlow16);
		float fSlow18 = float(fHslider8);
		float fSlow19 = ((1.0f - fSlow18) / std::max<float>(1.0f, (fConst2 * float(fHslider9))));
		float fSlow20 = (fSlow18 / std::max<float>(1.0f, (fConst2 * float(fHslider10))));
		float fSlow21 = (fConst4 * fSlow0);
		float fSlow22 = std::sin(fSlow21);
		float fSlow23 = std::cos(fSlow21);
		float fSlow24 = float(fHslider11);
		float fSlow25 = std::max<float>(1.0f, (fConst2 * float(fHslider12)));
		float fSlow26 = (1.0f / fSlow25);
		float fSlow27 = float(fHslider13);
		float fSlow28 = ((1.0f - fSlow27) / std::max<float>(1.0f, (fConst2 * float(fHslider14))));
		float fSlow29 = (fSlow27 / std::max<float>(1.0f, (fConst2 * float(fHslider15))));
		float fSlow30 = (fConst5 * fSlow0);
		float fSlow31 = std::sin(fSlow30);
		float fSlow32 = std::cos(fSlow30);
		float fSlow33 = float(fHslider16);
		float fSlow34 = std::max<float>(1.0f, (fConst2 * float(fHslider17)));
		float fSlow35 = (1.0f / fSlow34);
		float fSlow36 = float(fHslider18);
		float fSlow37 = ((1.0f - fSlow36) / std::max<float>(1.0f, (fConst2 * float(fHslider19))));
		float fSlow38 = (fSlow36 / std::max<float>(1.0f, (fConst2 * float(fHslider20))));
		float fSlow39 = (fConst6 * fSlow0);
		float fSlow40 = std::sin(fSlow39);
		float fSlow41 = std::cos(fSlow39);
		float fSlow42 = float(fHslider21);
		float fSlow43 = std::max<float>(1.0f, (fConst2 * float(fHslider22)));
		float fSlow44 = (1.0f / fSlow43);
		float fSlow45 = float(fHslider23);
		float fSlow46 = ((1.0f - fSlow45) / std::max<float>(1.0f, (fConst2 * float(fHslider24))));
		float fSlow47 = (fSlow45 / std::max<float>(1.0f, (fConst2 * float(fHslider25))));
		float fSlow48 = (fConst7 * fSlow0);
		float fSlow49 = std::sin(fSlow48);
		float fSlow50 = std::cos(fSlow48);
		float fSlow51 = float(fHslider26);
		float fSlow52 = std::max<float>(1.0f, (fConst2 * float(fHslider27)));
		float fSlow53 = (1.0f / fSlow52);
		float fSlow54 = float(fHslider28);
		float fSlow55 = ((1.0f - fSlow54) / std::max<float>(1.0f, (fConst2 * float(fHslider29))));
		float fSlow56 = (fSlow54 / std::max<float>(1.0f, (fConst2 * float(fHslider30))));
		float fSlow57 = (fConst8 * fSlow0);
		float fSlow58 = std::sin(fSlow57);
		float fSlow59 = std::cos(fSlow57);
		float fSlow60 = float(fHslider31);
		float fSlow61 = std::max<float>(1.0f, (fConst2 * float(fHslider32)));
		float fSlow62 = (1.0f / fSlow61);
		float fSlow63 = float(fHslider33);
		float fSlow64 = ((1.0f - fSlow63) / std::max<float>(1.0f, (fConst2 * float(fHslider34))));
		float fSlow65 = (fSlow63 / std::max<float>(1.0f, (fConst2 * float(fHslider35))));
		float fSlow66 = (fConst9 * fSlow0);
		float fSlow67 = std::sin(fSlow66);
		float fSlow68 = std::cos(fSlow66);
		float fSlow69 = float(fHslider36);
		float fSlow70 = std::max<float>(1.0f, (fConst2 * float(fHslider37)));
		float fSlow71 = (1.0f / fSlow70);
		float fSlow72 = float(fHslider38);
		float fSlow73 = ((1.0f - fSlow72) / std::max<float>(1.0f, (fConst2 * float(fHslider39))));
		float fSlow74 = (fSlow72 / std::max<float>(1.0f, (fConst2 * float(fHslider40))));
		for (int i = 0; (i < count); i = (i + 1)) {
			iVec0[0] = 1;
			fRec0[0] = ((fSlow2 * fRec1[1]) + (fSlow3 * fRec0[1]));
			float fTemp0 = float((1 - iVec0[1]));
			fRec1[0] = ((fTemp0 + (fSlow3 * fRec1[1])) - (fSlow2 * fRec0[1]));
			fVec1[0] = fSlow7;
			fRec2[0] = (fSlow7 + (fRec2[1] * float((fVec1[1] >= fSlow7))));
			iRec3[0] = (iSlow11 * (iRec3[1] + 1));
			float fTemp1 = float(iRec3[0]);
			fRec4[0] = ((fSlow13 * fRec5[1]) + (fSlow14 * fRec4[1]));
			fRec5[0] = ((fTemp0 + (fSlow14 * fRec5[1])) - (fSlow13 * fRec4[1]));
			fRec6[0] = ((fSlow22 * fRec7[1]) + (fSlow23 * fRec6[1]));
			fRec7[0] = ((fTemp0 + (fSlow23 * fRec7[1])) - (fSlow22 * fRec6[1]));
			fRec8[0] = ((fSlow31 * fRec9[1]) + (fSlow32 * fRec8[1]));
			fRec9[0] = ((fTemp0 + (fSlow32 * fRec9[1])) - (fSlow31 * fRec8[1]));
			fRec10[0] = ((fSlow40 * fRec11[1]) + (fSlow41 * fRec10[1]));
			fRec11[0] = ((fTemp0 + (fSlow41 * fRec11[1])) - (fSlow40 * fRec10[1]));
			fRec12[0] = ((fSlow49 * fRec13[1]) + (fSlow50 * fRec12[1]));
			fRec13[0] = ((fTemp0 + (fSlow50 * fRec13[1])) - (fSlow49 * fRec12[1]));
			fRec14[0] = ((fSlow58 * fRec15[1]) + (fSlow59 * fRec14[1]));
			fRec15[0] = ((fTemp0 + (fSlow59 * fRec15[1])) - (fSlow58 * fRec14[1]));
			fRec16[0] = ((fSlow67 * fRec17[1]) + (fSlow68 * fRec16[1]));
			fRec17[0] = ((fTemp0 + (fSlow68 * fRec17[1])) - (fSlow67 * fRec16[1]));
			output0[i] = FAUSTFLOAT((0.125f * ((((((((fRec0[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow4 * std::max<float>(0.0f, (std::min<float>((fSlow6 * fRec2[0]), std::max<float>(((fSlow9 * (fSlow5 - fRec2[0])) + 1.0f), fSlow8)) - (fSlow10 * fTemp1))))))) + (fRec4[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow15 * std::max<float>(0.0f, (std::min<float>((fSlow17 * fRec2[0]), std::max<float>(((fSlow19 * (fSlow16 - fRec2[0])) + 1.0f), fSlow18)) - (fSlow20 * fTemp1)))))))) + (fRec6[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow24 * std::max<float>(0.0f, (std::min<float>((fSlow26 * fRec2[0]), std::max<float>(((fSlow28 * (fSlow25 - fRec2[0])) + 1.0f), fSlow27)) - (fSlow29 * fTemp1)))))))) + (fRec8[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow33 * std::max<float>(0.0f, (std::min<float>((fSlow35 * fRec2[0]), std::max<float>(((fSlow37 * (fSlow34 - fRec2[0])) + 1.0f), fSlow36)) - (fSlow38 * fTemp1)))))))) + (fRec10[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow42 * std::max<float>(0.0f, (std::min<float>((fSlow44 * fRec2[0]), std::max<float>(((fSlow46 * (fSlow43 - fRec2[0])) + 1.0f), fSlow45)) - (fSlow47 * fTemp1)))))))) + (fRec12[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow51 * std::max<float>(0.0f, (std::min<float>((fSlow53 * fRec2[0]), std::max<float>(((fSlow55 * (fSlow52 - fRec2[0])) + 1.0f), fSlow54)) - (fSlow56 * fTemp1)))))))) + (fRec14[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow60 * std::max<float>(0.0f, (std::min<float>((fSlow62 * fRec2[0]), std::max<float>(((fSlow64 * (fSlow61 - fRec2[0])) + 1.0f), fSlow63)) - (fSlow65 * fTemp1)))))))) + (fRec16[0] * std::min<float>(1.0f, std::max<float>(0.0f, (fSlow69 * std::max<float>(0.0f, (std::min<float>((fSlow71 * fRec2[0]), std::max<float>(((fSlow73 * (fSlow70 - fRec2[0])) + 1.0f), fSlow72)) - (fSlow74 * fTemp1))))))))));
			iVec0[1] = iVec0[0];
			fRec0[1] = fRec0[0];
			fRec1[1] = fRec1[0];
			fVec1[1] = fVec1[0];
			fRec2[1] = fRec2[0];
			iRec3[1] = iRec3[0];
			fRec4[1] = fRec4[0];
			fRec5[1] = fRec5[0];
			fRec6[1] = fRec6[0];
			fRec7[1] = fRec7[0];
			fRec8[1] = fRec8[0];
			fRec9[1] = fRec9[0];
			fRec10[1] = fRec10[0];
			fRec11[1] = fRec11[0];
			fRec12[1] = fRec12[0];
			fRec13[1] = fRec13[0];
			fRec14[1] = fRec14[0];
			fRec15[1] = fRec15[0];
			fRec16[1] = fRec16[0];
			fRec17[1] = fRec17[0];
		}
	}

};

/***************************END USER SECTION ***************************/

/*******************BEGIN ARCHITECTURE SECTION (part 2/2)***************/

//#define A1S_BOARD true                  //uncomment for Ai-thinker A1S board

#define MULT_S32 2147483647
#define DIV_S32 4.6566129e-10
#define clip(sample) std::max(-MULT_S32, std::min(MULT_S32, ((int32_t)(sample * MULT_S32))));

AdditiveSynth::AdditiveSynth(int sample_rate, int buffer_size)
{
    fBS = buffer_size;
    fDSP = new mydsp();
    fDSP->init(sample_rate);
    fUI = new MapUI();
    fDSP->buildUserInterface(fUI);
    fHandle = NULL;
    
    i2s_pin_config_t pin_config;
#if TTGO_TAUDIO
    pin_config = {
        .bck_io_num = 33,
        .ws_io_num = 25,
        .data_out_num = 26,
        .data_in_num = 27
    };
#elif A1S_BOARD
    pin_config = {
        .bck_io_num = 27,
        .ws_io_num = 26,
        .data_out_num = 25,
        .data_in_num = 35
    };
#else // Default
    pin_config = {
        .bck_io_num = 33,
        .ws_io_num = 25,
        .data_out_num = 26,
        .data_in_num = 27
    };
#endif
    configureI2S(sample_rate, buffer_size, pin_config);
    
    if (fDSP->getNumInputs() > 0) {
        fInChannel = new float*[fDSP->getNumInputs()];
        for (int i = 0; i < fDSP->getNumInputs(); i++) {
            fInChannel[i] = new float[fBS];
        }
    }
    if (fDSP->getNumOutputs() > 0) {
        fOutChannel = new float*[fDSP->getNumOutputs()];
        for (int i = 0; i < fDSP->getNumOutputs(); i++) {
            fOutChannel[i] = new float[fBS];
        }
    }
}

AdditiveSynth::~AdditiveSynth()
{
    for (int i = 0; i < fDSP->getNumInputs(); i++) {
        delete[] fInChannel[i];
    }
    delete [] fInChannel;
    
    for (int i = 0; i < fDSP->getNumOutputs(); i++) {
        delete[] fOutChannel[i];
    }
    delete [] fOutChannel;
    
    delete fDSP;
    delete fUI;
}

bool AdditiveSynth::start()
{
    xTaskCreate(audioTaskHandler, "Faust DSP Task", 1024, (void*)this, 5, &fHandle);
    return true;
}

void AdditiveSynth::stop()
{
    if (fHandle != NULL) {
        vTaskDelete(fHandle);
        fHandle = NULL;
    }
}

void AdditiveSynth::setParamValue(const std::string& path, float value)
{
    fUI->setParamValue(path, value);
}

void AdditiveSynth::configureI2S(int sample_rate, int buffer_size, i2s_pin_config_t pin_config)
{
    #if A1S_BOARD
    i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX),
        .sample_rate = sample_rate,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
        .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1, // high interrupt priority
        .dma_buf_count = 3,
        .dma_buf_len = buffer_size,
        .use_apll = true
    };
    #else // default
        i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX),
        .sample_rate = sample_rate,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
        .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1, // high interrupt priority
        .dma_buf_count = 3,
        .dma_buf_len = buffer_size,
        .use_apll = false
    };
    #endif
    i2s_driver_install((i2s_port_t)0, &i2s_config, 0, NULL);
    i2s_set_pin((i2s_port_t)0, &pin_config);
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO0_U, FUNC_GPIO0_CLK_OUT1);
    REG_WRITE(PIN_CTRL, 0xFFFFFFF0);
}

void AdditiveSynth::audioTask()
{
    while (true) {
        if (fDSP->getNumInputs() > 0) {
            
            // Read from the card
            int32_t samples_data_in[2*fBS];
            size_t bytes_read = 0;
            i2s_read((i2s_port_t)0, &samples_data_in, 8*fBS, &bytes_read, portMAX_DELAY);
            
            // Convert and copy inputs
            if (fDSP->getNumInputs() == 2) { // if stereo
                for (int i = 0; i < fBS; i++) {
                    fInChannel[0][i] = (float)samples_data_in[i*2]*DIV_S32;
                    fInChannel[1][i] = (float)samples_data_in[i*2+1]*DIV_S32;
                }
            } else {
                for (int i = 0; i < fBS; i++) {
                    fInChannel[0][i] = (float)samples_data_in[i*2]*DIV_S32;
                }
            }
        }
        
        // Call DSP
        fDSP->compute(fBS, fInChannel, fOutChannel);
        
        // Convert and copy outputs
        int32_t samples_data_out[2*fBS];
        if (fDSP->getNumOutputs() == 2) {
            // if stereo
            for (int i = 0; i < fBS; i++) {
                samples_data_out[i*2] = clip(fOutChannel[0][i]);
                samples_data_out[i*2+1] = clip(fOutChannel[1][i]);
            }
        } else {
            // otherwise only first channel
            for (int i = 0; i < fBS; i++) {
                samples_data_out[i*2] = clip(fOutChannel[0][i]);
                samples_data_out[i*2+1] = samples_data_out[i*2];
            }
        }
        
        // Write to the card
        size_t bytes_writen = 0;
        i2s_write((i2s_port_t)0, &samples_data_out, 8*fBS, &bytes_writen, portMAX_DELAY);
    }
}

void AdditiveSynth::audioTaskHandler(void* arg)
{
    AdditiveSynth* audio = (AdditiveSynth*)arg;
    audio->audioTask();
}

/********************END ARCHITECTURE SECTION (part 2/2)****************/

#endif
